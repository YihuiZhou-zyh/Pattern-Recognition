create view nonpassstu as
  select `school`.`s`.`xh`   AS `xh`,
         `school`.`s`.`xm`   AS `xm`,
         `school`.`s`.`xb`   AS `xb`,
         `school`.`s`.`sjhm` AS `sjhm`,
         `school`.`e`.`kh`   AS `kh`,
         `school`.`e`.`zpcj` AS `zpcj`
  from `school`.`s`
         join `school`.`e`
  where ((`school`.`s`.`xh` = `school`.`e`.`xh`) and (`school`.`e`.`zpcj` < 60));

