create procedure addnum()
  begin
    declare i int default 10000000;
        while i>0 do
        insert into Table_1 values(i);
          set i=i-1;
        end while;
  end;

